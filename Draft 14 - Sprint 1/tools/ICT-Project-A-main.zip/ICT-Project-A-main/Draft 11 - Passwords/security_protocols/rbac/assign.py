from supabase_client.supabaseClient import supabase

def get_assigned_residents(user_id, role):  # ✅ Rename parameter
    if role not in ["nurse", "carer"]:
        return []

    # ✅ No need to convert user_id — it's already a string
    response = supabase.table("assignments").select("resident_id").eq("staff_id", user_id).execute()
    if not response.data:
        return []

    resident_ids = [entry["resident_id"] for entry in response.data]
    resident_response = supabase.table("residents").select("*").in_("id", resident_ids).execute()
    return resident_response.data

