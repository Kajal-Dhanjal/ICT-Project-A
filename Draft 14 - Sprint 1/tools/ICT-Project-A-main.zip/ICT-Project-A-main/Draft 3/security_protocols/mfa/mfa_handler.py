def verify_code(code):
    return code == "123456"
