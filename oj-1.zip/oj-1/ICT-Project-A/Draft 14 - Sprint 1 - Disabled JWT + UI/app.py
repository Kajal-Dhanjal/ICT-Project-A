# app.py
from flask import Flask, render_template, request, redirect, g, send_from_directory, Response, url_for, make_response, session, send_file
from flask_wtf import FlaskForm, CSRFProtect
from wtforms import StringField, PasswordField
from wtforms.validators import DataRequired
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.utils import secure_filename
from datetime import datetime
from threading import Thread
import os
from dotenv import load_dotenv

from supabase_client.supabaseClient import supabase
from security_protocols.rbac.rbac import get_user_by_email, get_all_users, get_all_residents
from security_protocols.rbac.assign import get_assigned_residents
from security_protocols.rbac.permissions import get_latest_vitals_for_resident
from security_protocols.rbac.invite import create_invite_token, verify_invite_token, complete_registration
from security_protocols.rbac.email_inviter import send_invite_email
from security_protocols.jwt.auth import jwt_required
from security_protocols.jwt.jwt_handler import generate_jwt
from security_protocols.monitoring.logger import log_activity, get_logs, get_honeypot_logs
from security_protocols.honeypot.honeypot_handler import honeypot
from security_protocols.mfa.mfa import verify_mfa_otp, mfa_required

# Forms
class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])

class RegisterForm(FlaskForm):
    password = PasswordField('Password', validators=[DataRequired()])

class ForgotForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired()])

# Load environment variables
load_dotenv()

app = Flask(__name__, template_folder="web_interface/templates")
app.secret_key = os.getenv("FLASK_SECRET_KEY", "fallback_super_secret")

csrf = CSRFProtect(app)
limiter = Limiter(app=app, key_func=get_remote_address, default_limits=["2000 per day", "500 per hour"])

secret_key = app.secret_key

# Honeypot
from flask import Flask as HoneypotFlask
honeypot_app = HoneypotFlask(__name__)
honeypot_app.register_blueprint(honeypot)

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/login", methods=["GET", "POST"])
@limiter.limit("500 per minute")
def login():
    form = LoginForm()
    if request.method == "GET":
        return render_template("login.html", form=form)

    if not form.validate_on_submit():
        return render_template("login.html", form=form, error="Invalid input")

    email = form.email.data
    password = form.password.data

    try:
        auth_response = supabase.auth.sign_in_with_password({"email": email, "password": password})
        if auth_response.session and auth_response.session.access_token:
            user = supabase.table("users").select("id, role, mfa_secret").eq("email", email).single().execute()
            if not user.data:
                return "User not registered", 403

            log_activity(user.data["id"], "Successful login", email=email)

            session["pending_user"] = {
                "email": email,
                "user_id": user.data["id"],
                "access_token": auth_response.session.access_token
            }
            return redirect("/mfa" if user.data.get("mfa_secret") else "/mfa/setup")
        else:
            return render_template("login.html", form=form, error="Invalid credentials")
    except Exception as e:
        print(f"Login error: {e}")
        return render_template("login.html", form=form, error="Login error")

@app.route("/mfa", methods=["GET"])
def mfa_page():
    pending = session.get("pending_user")
    if not pending:
        return redirect("/login")

    user_id = pending["user_id"]
    result = supabase.table("users").select("mfa_secret").eq("id", user_id).single().execute()
    if not result.data.get("mfa_secret"):
        return redirect("/mfa/setup")

    return render_template("mfa.html", user_id=user_id)

@app.route("/mfa/validate", methods=["POST"])
def mfa_validate():
    user_id = request.form.get("user_id")
    otp = request.form.get("otp", "").strip()

    if not user_id or not otp:
        return render_template("mfa.html", error="Missing user ID or OTP", user_id=user_id)

    result, status_code = verify_mfa_otp(user_id, otp)

    if result["status"] == "success":
        user_info = supabase.table("users").select("email, role").eq("id", user_id).single().execute().data
        log_activity(user_id, "Successful login (MFA)", email=user_info["email"])

        token = generate_jwt(user_id, user_info["role"], mfa_verified=True)

        resp = make_response(redirect("/dashboard"))
        resp.set_cookie("access_token", token, httponly=True)
        return resp

    return render_template("mfa.html", error=result["message"], user_id=user_id)

@app.route("/dashboard")
@jwt_required
@mfa_required
def dashboard():
    if g.role == "admin":
        return redirect("/admin_dashboard")
    elif g.role in ["nurse", "carer"]:
        return redirect("/care_plan_dashboard")
    elif g.role == "resident":
        return redirect("/resident_dashboard")
    return "Unauthorized", 403

@app.route("/admin_dashboard")
@jwt_required
@mfa_required
def admin_dashboard():
    if g.role != "admin":
        return "Unauthorized", 403

    user = supabase.table("users").select("*").eq("id", g.user_id).single().execute().data
    if not user or "email" not in user:
        user = {"email": "Unknown"}

    users = get_all_users()
    residents = get_all_residents()
    logs = get_logs()
    honeypot_logs = get_honeypot_logs()

    return render_template("admin_dashboard.html",
        user=user,
        users=users,
        residents=residents,
        logs=logs,
        honeypot_logs=honeypot_logs
    )
@app.route("/logout")
@jwt_required
@mfa_required
def logout():
    log_activity(g.user_id, "Logged out")
    resp = redirect("/login")
    resp.delete_cookie("access_token")
    return resp

@app.route("/register", methods=["GET", "POST"])
@limiter.limit("3600 per hour")
def register():
    token = request.args.get("token") if request.method == "GET" else request.form.get("token")
    form = RegisterForm()
    invite = verify_invite_token(token)

    if not invite or isinstance(invite, Response):
        return "Invalid or expired invite link", 400

    invite_data = invite[0] if isinstance(invite, tuple) else invite

    if request.method == "GET":
        return render_template("register.html", form=form, token=token, email=invite_data.get("email"))

    if not form.validate_on_submit():
        return render_template("register.html", form=form, token=token, error="Invalid input")

    try:
        result = complete_registration(token, form.password.data)
        return render_template("register_success.html")
    except Exception as e:
        return str(e), 400

@app.route("/admin/invite", methods=["GET", "POST"])
@jwt_required
@mfa_required
def admin_invite():
    if g.role != "admin":
        return "Unauthorized", 403  # ✅ Block non-admins

    invite_link = None
    if request.method == "POST":
        email = request.form.get("email")
        role = request.form.get("role")
        token = create_invite_token(email, role)
        invite_link = f"{request.host_url}register?token={token}"

    return render_template("invite_form.html", invite_link=invite_link)



# --- [MFA QR Code Setup for Microsoft Authenticator] ---
import pyotp
import pyqrcode

@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    form = ForgotForm()
    if request.method == "GET":
        return render_template("forgot_password.html", form=form)

    if not form.validate_on_submit():
        return render_template("forgot_password.html", form=form, message="Invalid input.")

    email = form.email.data
    user = get_user_by_email(email)
    if not user:
        return render_template("forgot_password.html", form=form, message="No user found.")

    from itsdangerous import URLSafeTimedSerializer
    s = URLSafeTimedSerializer(secret_key)
    token = s.dumps(email, salt="password-reset")
    reset_link = url_for("reset_password", token=token, _external=True)
    send_invite_email(email, reset_link)

    return render_template("forgot_password.html", form=form, message="Reset link sent.")

# Add more routes here like /reset-password, /mfa/validate, etc. if needed

if __name__ == "__main__":
    Thread(target=lambda: app.run(port=5000, debug=True, use_reloader=False)).start()
    Thread(target=lambda: honeypot_app.run(port=3000, debug=True, use_reloader=False)).start()
